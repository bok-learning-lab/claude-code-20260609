#!/usr/bin/python
from random import random
import numpy as np
import matplotlib.pyplot as plt

# Time steps
tmax = 200

# Max spatial steps
nmax = 2*tmax

# Number of walkers and initial positions
nwalkers = 100
x = [0]*nwalkers

# Bin random walk positions into an empty 2x2 array (time, bin)
bins = np.zeros((tmax,nmax+1)) # tmax rows x nmax+1 columns
bins[0,nmax/2+1] = nwalkers  # all walkers initially at x=0

# Intialize statistics
meanx = [0]*tmax
widthx = [0]*tmax

# Time iteration
for i in xrange(1,tmax):
    
    # Walker iteration
    for j in xrange(nwalkers):
        
        if random()>0.5:
            x[j] += 1
        else:
            x[j] -= 1
        
        # Increment count for location of x[j]
        bins[i,x[j]+int(nmax/2)-1] += 1 # recenter bins around x=0
            
    # Statistics
    meanx[i] = sum(x)/float(len(x))
    widthx[i] = np.std(x)/np.sqrt(2)
        
# Sample plots -- very crude!
def walker_hist(i):
    plt.figure(i)
    binx = np.arange(np.shape(bins)[1])-np.shape(bins)[1]/2-1.5
    biny = bins[i,:]
    plt.bar(binx,biny,width=1) #width here is just a plot style option
    plt.xlim([-nmax/40, nmax/40])
    
walker_hist(0),walker_hist(1),walker_hist(2)